/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ClientApp } from './components/ClientApp';
import { DriverApp } from './components/DriverApp';
import { AdminPanel } from './components/AdminPanel';
import { AuthFlow } from './components/AuthFlow';
import { Order, UserProfile, DRIVER_RECHARGE_FEE, SUPPORT_NUMBER, PaymentTransaction, AdminNotification } from './types';
import { Truck, User as UserIcon, ArrowRightLeft, ShieldCheck, Power, Check, X } from 'lucide-react';
import { cn } from './lib/utils';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrderId, setActiveOrderId] = useState<string | null>(null);
  const [supportNumber, setSupportNumber] = useState(SUPPORT_NUMBER);
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [notifications, setNotifications] = useState<AdminNotification[]>([]);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error' | 'info'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Persistence simulation
  useEffect(() => {
    const savedOrders = localStorage.getItem('amafrican_orders');
    if (savedOrders) setOrders(JSON.parse(savedOrders));

    const savedTransactions = localStorage.getItem('amafrican_transactions');
    if (savedTransactions) setTransactions(JSON.parse(savedTransactions));

    const savedUsers = localStorage.getItem('amafrican_users');
    if (savedUsers) setUsers(JSON.parse(savedUsers));

    const savedSupport = localStorage.getItem('amafrican_support_number');
    if (savedSupport) setSupportNumber(savedSupport);

    const savedNotifications = localStorage.getItem('amafrican_notifications');
    if (savedNotifications) setNotifications(JSON.parse(savedNotifications));

    const savedUser = localStorage.getItem('amafrican_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      // Check if session is older than 1 week
      if (Date.now() - parsedUser.lastLogin < 7 * 24 * 60 * 60 * 1000) {
        setUser(parsedUser);
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('amafrican_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('amafrican_transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem('amafrican_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('amafrican_support_number', supportNumber);
  }, [supportNumber]);

  useEffect(() => {
    localStorage.setItem('amafrican_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    if (user) localStorage.setItem('amafrican_user', JSON.stringify(user));
  }, [user]);

  const handleLogin = (newUser: UserProfile) => {
    setUser(newUser);
    setUsers(prev => {
      const exists = prev.find(u => u.phone === newUser.phone);
      if (exists) {
        return prev.map(u => u.phone === newUser.phone ? { ...u, ...newUser, lastLogin: Date.now() } : u);
      }
      return [...prev, newUser];
    });
  };

  const handleNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const handleNewNotification = (notif: Omit<AdminNotification, 'id' | 'timestamp' | 'read'>) => {
    const newNotif: AdminNotification = {
      ...notif,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('amafrican_user');
  };

  const handleRecharge = () => {
    if (!user) return;
    
    const newTransaction: PaymentTransaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      userName: user.name,
      amount: 300,
      type: 'subscription',
      status: 'completed',
      timestamp: Date.now(),
    };

    setTransactions(prev => [...prev, newTransaction]);
    
    const updatedUser: UserProfile = {
      ...user,
      subscriptionExpiry: Date.now() + 30 * 24 * 60 * 60 * 1000,
    };
    setUser(updatedUser);
  };

  const handleOrderCreated = (order: Order) => {
    setOrders(prev => [...prev, order]);
    setActiveOrderId(order.id);
  };

  const handleAcceptOrder = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'accepted' as const, driverId: user?.id } : o));
    setActiveOrderId(orderId);
  };

  const handleCompleteOrder = (orderId: string) => {
    const orderToComplete = orders.find(o => o.id === orderId);
    if (orderToComplete) {
      const commission = orderToComplete.commission || 0;
      const commissionTx: PaymentTransaction = {
        id: `comm_${orderToComplete.id}`,
        userId: user?.id || 'unknown',
        userName: user?.name || 'unknown',
        amount: commission,
        type: 'commission',
        status: 'completed',
        timestamp: Date.now(),
      };
      setTransactions(t => [...t, commissionTx]);
    }

    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'completed' as const } : o));
    setActiveOrderId(null);
  };

  const handleRejectOrder = (orderId: string) => {
    setOrders(prev => prev.filter(o => o.id !== orderId));
  };

  const handleVerifyDriver = (userId: string) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, isVerified: true } : u));
    if (user?.id === userId) {
      setUser(prev => prev ? { ...prev, isVerified: true } : null);
    }
  };

  const handleRewardUser = (userId: string, amount: number) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, bonusBalance: (u.bonusBalance || 0) + amount } : u));
    setTransactions(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      userId,
      userName: users.find(u => u.id === userId)?.name || 'Motorista',
      amount,
      type: 'bonus',
      status: 'completed',
      timestamp: Date.now()
    }]);
  };

  const handleRemoveUser = (userId: string) => {
    if (confirm("Tem certeza que deseja remover este utilizador? Esta acção é irreversível.")) {
      setUsers(prev => prev.filter(u => u.id !== userId));
      if (user?.id === userId) setUser(null);
    }
  };

  const activeOrder = orders.find(o => o.id === activeOrderId);

  if (!user) {
    return <div className="mobile-container"><AuthFlow onLogin={handleLogin} onNewNotification={handleNewNotification} onToast={showToast} /></div>;
  }

  const role = user.role;
  const isDriverSubscribed = user.subscriptionExpiry ? user.subscriptionExpiry > Date.now() : false;

  return (
    <div className="mobile-container">
      <div className="flex-1 overflow-hidden">
        {role === 'client' && (
          <ClientApp 
            user={user}
            onOrderCreated={handleOrderCreated} 
            activeOrder={activeOrder}
            onToast={showToast}
          />
        )}
        {role === 'driver' && (
          <DriverApp 
            orders={orders}
            user={user}
            activeOrder={activeOrder && activeOrder.status !== 'pending' ? activeOrder : undefined}
            onAcceptOrder={handleAcceptOrder}
            onCompleteOrder={handleCompleteOrder}
            onRejectOrder={handleRejectOrder}
            onRecharge={handleRecharge}
            isSubscribed={isDriverSubscribed}
            supportNumber={supportNumber}
            onToast={showToast}
          />
        )}
        {role === 'admin' && (
          <AdminPanel 
            orders={orders} 
            transactions={transactions}
            users={users}
            notifications={notifications}
            onNotificationsRead={handleNotificationsRead}
            onVerifyDriver={handleVerifyDriver}
            onRewardUser={handleRewardUser}
            onRemoveUser={handleRemoveUser}
            supportNumber={supportNumber}
            onUpdateSupport={setSupportNumber}
            onToast={showToast}
          />
        )}
      </div>

      {/* Role Toggle Floating Button */}
      {user && user.role !== 'admin' && (
        <button 
          onClick={() => {
            const nextRole = user.role === 'client' ? 'driver' : 'client';
            setUser({ ...user, role: nextRole });
            setActiveOrderId(null);
          }}
          className="absolute bottom-24 right-6 bg-primary-pink text-white p-4 rounded-full shadow-2xl z-50 flex items-center justify-center border-4 border-white active:scale-90 transition-transform group"
        >
          <ArrowRightLeft className="w-6 h-6" />
          <span className="absolute -top-12 right-0 bg-white text-primary-pink text-[10px] font-black px-4 py-2 rounded-full border-2 border-primary-pink shadow-xl whitespace-nowrap pointer-events-none">
            {user.role === 'client' ? 'Sou Motorista' : 'Sou Cliente'}
          </span>
        </button>
      )}

      {/* Bottom Nav */}
      <nav className={cn(
        "h-20 border-t flex items-center justify-around px-6 pb-2 transition-colors",
        role === 'client' ? "bg-white border-stone-100" : role === 'driver' ? "bg-driver-dark border-white/5" : "bg-slate-50 border-slate-200"
      )}>
        <button 
          onClick={() => {}}
          className={cn(
            "flex flex-col items-center gap-1 transition-colors",
            role === 'client' ? "text-primary-pink" : role === 'driver' ? "text-emerald-400" : "text-primary-red"
          )}
        >
          <div className={cn("p-2 rounded-xl", role === 'client' ? "bg-pink-50" : role === 'driver' ? "bg-emerald-400/10" : "bg-red-50")}>
            {role === 'client' ? <UserIcon size={20} /> : role === 'driver' ? <Truck size={20} /> : <ShieldCheck size={20} />}
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest font-sans">Home</span>
        </button>
        <button 
          onClick={handleLogout}
          className="flex flex-col items-center gap-1 text-stone-300"
        >
          <div className="p-2">
            <Power size={20} className="rotate-90" />
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest font-sans">Sair</span>
        </button>
        <button className="flex flex-col items-center gap-1 text-stone-300 opacity-40">
          <div className="p-2">
            <UserIcon size={20} />
          </div>
          <span className="text-[9px] font-black uppercase tracking-widest font-sans">Perfil</span>
        </button>
      </nav>

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="absolute bottom-32 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-[300px]"
          >
            <div className={cn(
              "p-4 rounded-2xl shadow-2xl flex items-center gap-3 border backdrop-blur-md",
              toast.type === 'success' ? "bg-emerald-500/90 border-emerald-400 text-white" : 
              toast.type === 'error' ? "bg-red-500/90 border-red-400 text-white" :
              "bg-stone-800/90 border-stone-700 text-white"
            )}>
              {toast.type === 'success' && <Check size={18} />}
              {toast.type === 'error' && <X size={18} />}
              {toast.type === 'info' && <ShieldCheck size={18} />}
              <p className="text-[10px] font-black uppercase tracking-widest">{toast.message}</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
