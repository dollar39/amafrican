/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ServiceType = 'merchandise' | 'materials' | 'people';
export type DriverCategory = 'ligeiro' | 'pesado' | 'pesado_profissional';

export interface VehicleType {
  id: string;
  name: string;
  icon: string;
  description: string;
  basePrice: number;
  pricePerKm: number;
}

export interface Order {
  id: string;
  serviceType: ServiceType;
  vehicleType: string;
  status: 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';
  pickup: {
    lat: number;
    lng: number;
    address: string;
  };
  destination: {
    lat: number;
    lng: number;
    address: string;
  };
  price: number;
  commission: number;
  customerId: string;
  customerName?: string;
  customerPhone?: string;
  driverId?: string;
  cargoDescription?: string;
  cargoPhoto?: string;
  createdAt: number;
}

export const COMMISSION_RATE = 0.15; // 15% commission for the platform

export interface UserProfile {
  id: string;
  name: string;
  role: 'client' | 'driver' | 'admin';
  phone: string;
  lastLogin: number;
  subscriptionExpiry?: number; // For drivers
  rating: number;
  bonusBalance?: number;
  carBrand?: string;
  carLuxury?: number; // 0-100 percentage
  isAvailable?: boolean;
  isVerified?: boolean; // For drivers verification by admin
  birthDate?: string; // DD/MM/YYYY
  biNumber?: string;
  biPhoto?: string;
  licensePhoto?: string;
  profilePhoto?: string;
  vehiclePhoto?: string;
  vehiclePhotos?: {
    inside: string[];
    outside: string[];
  };
  vehiclePlate?: string;
  driverCategory?: DriverCategory;
  vehicleCategory?: ServiceType;
  vehicleSubCategory?: string;
  registrationStep?: 'complete' | 'profile_setup';
}

export interface AdminNotification {
  id: string;
  type: 'driver_registration' | 'payment' | 'support';
  title: string;
  message: string;
  userId: string;
  userName: string;
  timestamp: number;
  read: boolean;
}

export const COMMISSIONS_TOTAL_LIMIT = 200; // Max bonus admin can give
export const DRIVER_RECHARGE_FEE = 300;
export const PIN_CHANGE_COOLDOWN = 60 * 24 * 60 * 60 * 1000; // 60 days in ms
export const DEFAULT_ADMIN_PIN = "123456";

export const MAPUTO_CENTER = { lat: -25.9692, lng: 32.5732 };
export const SUPPORT_NUMBER = "+258 84 000 0000";

export interface PaymentTransaction {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  type: 'subscription' | 'commission' | 'bonus' | 'penalty';
  status: 'pending' | 'completed';
  timestamp: number;
}

export const SERVICES = [
  { id: 'people', name: 'Pessoas', icon: 'User', color: 'bg-pink-600' },
  { id: 'merchandise', name: 'Mercadorias', icon: 'Package', color: 'bg-yellow-500' },
  { id: 'materials', name: 'Materiais', icon: 'HardHat', color: 'bg-red-700' },
] as const;

export const VEHICLES: Record<ServiceType, VehicleType[]> = {
  merchandise: [
    { id: 'food', name: 'Alimentos', icon: 'ShoppingBag', description: 'Transporte de comida e perecíveis', basePrice: 150, pricePerKm: 25 },
    { id: 'fast_delivery', name: 'Entrega Rápida', icon: 'Zap', description: 'Encomendas urgentes', basePrice: 100, pricePerKm: 20 },
  ],
  materials: [
    { id: 'blocks', name: 'Blocos', icon: 'Box', description: 'Blocos de cimento e pavimentação', basePrice: 500, pricePerKm: 60 },
    { id: 'cement', name: 'Cimento', icon: 'Package', description: 'Sacos de cimento', basePrice: 400, pricePerKm: 50 },
    { id: 'construction_general', name: 'Material de Construção', icon: 'Hammer', description: 'Areia, pedra e ferro', basePrice: 600, pricePerKm: 70 },
    { id: 'accessories', name: 'Acessórios', icon: 'Tool', description: 'Ferragens e miudezas', basePrice: 300, pricePerKm: 40 },
  ],
  people: [
    { id: 'standard', name: 'Pessoas', icon: 'Users', description: 'Transporte individual ou colectivo', basePrice: 80, pricePerKm: 15 },
  ],
};
