import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, Lock as LockIcon, ArrowRight, MessageSquare, ShieldCheck, Camera as CameraIcon, Car, FileText, User as UserIcon, Tag as TagIcon, MoreVertical } from 'lucide-react';
import { cn } from '../lib/utils';
import { UserProfile, SERVICES, VEHICLES, ServiceType } from '../types';

interface AuthFlowProps {
  onLogin: (user: UserProfile) => void;
  onNewNotification: (notif: any) => void;
  onToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export function AuthFlow({ onLogin, onNewNotification, onToast }: AuthFlowProps) {
  const [step, setStep] = useState<'phone' | 'otp' | 'profile_basic' | 'profile_docs' | 'profile_vehicle'>('phone');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [role, setRole] = useState<'client' | 'driver'>('client');
  const [isLoading, setIsLoading] = useState(false);

  // Profile data
  const [name, setName] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [biNumber, setBiNumber] = useState('');
  const [biPhoto, setBiPhoto] = useState<string | null>(null);
  const [licensePhoto, setLicensePhoto] = useState<string | null>(null);
  const [vehicleCategory, setVehicleCategory] = useState<ServiceType>('people');
  const [carBrand, setCarBrand] = useState('');
  const [carLuxury, setCarLuxury] = useState(50);
  const [driverCategory, setDriverCategory] = useState<'ligeiro' | 'pesado' | 'pesado_profissional'>('ligeiro');
  const [vehicleSubCategory, setVehicleSubCategory] = useState('standard');
  const [plate, setPlate] = useState('');
  const [profilePhoto, setProfilePhoto] = useState<string | null>(null);
  const [vehiclePhotosInside, setVehiclePhotosInside] = useState<string[]>([]);
  const [vehiclePhotosOutside, setVehiclePhotosOutside] = useState<string[]>([]);
  const [countdown, setCountdown] = useState(30);
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [otpError, setOtpError] = useState(false);
  const [isVerifyingBI, setIsVerifyingBI] = useState(false);
  const [showAdminMenu, setShowAdminMenu] = useState(false);

  useEffect(() => {
    let timer: any;
    if (step === 'otp' && countdown > 0) {
      timer = setInterval(() => {
        setCountdown(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [step, countdown]);

  const handleSendOTP = () => {
    if (phone.length < 9 && phone !== '840000000') return;
    setIsLoading(true);

    // Hardcoded admin access for demo
    if (phone === '840000000') {
      setRole('admin');
    }
    
    // Generate unique 4-digit OTP
    const newOtp = phone === '840000000' ? '0000' : Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedOtp(newOtp);
    
    setTimeout(() => {
      setIsLoading(false);
      setCountdown(30);
      setStep('otp');
      setOtpError(false);
      // In a real app, this would be sent via SMS (AFTP)
      console.log(`AFTP OTP: ${newOtp}`);
    }, 1200);
  };

  const handleVerifyOTP = () => {
    if (otp.length < 4) return;
    if (otp !== generatedOtp) {
      setOtpError(true);
      return;
    }
    
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (role === 'admin') {
        const newUser: UserProfile = {
          id: 'admin',
          name: 'Administrador',
          role: 'admin',
          phone: phone,
          lastLogin: Date.now(),
          rating: 5.0,
          registrationStep: 'complete',
        };
        onLogin(newUser);
      } else if (role === 'driver') {
        setStep('profile_basic');
      } else {
        const newUser: UserProfile = {
          id: Math.random().toString(36).substr(2, 9),
          name: 'Usuário',
          role: 'client',
          phone: phone,
          lastLogin: Date.now(),
          rating: 5.0,
          registrationStep: 'complete',
        };
        onLogin(newUser);
      }
    }, 1000);
  };

  const handleVerifyBI = () => {
    if (!biNumber || !biPhoto) return;
    
    // BI Validation: 13 characters (12 numbers + 1 letter)
    const biRegex = /^\d{12}[A-Za-z]$/;
    if (!biRegex.test(biNumber)) {
      onToast("BI Inválido: 12 números e 1 letra.", 'error');
      return;
    }

    setIsVerifyingBI(true);
    setTimeout(() => {
      setIsVerifyingBI(false);
      setStep('profile_docs');
    }, 2000);
  };

  const handleCompleteProfile = () => {
    setIsLoading(true);
    setTimeout(() => {
      const newUser: UserProfile = {
        id: Math.random().toString(36).substr(2, 9),
        name: name || 'Motorista',
        role: 'driver',
        phone: phone,
        birthDate: birthDate,
        biNumber: biNumber,
        biPhoto: biPhoto || undefined,
        licensePhoto: licensePhoto || undefined,
        lastLogin: Date.now(),
        rating: 5.0,
        subscriptionExpiry: Date.now(), // Needs to pay 300MT first
        isVerified: false, // Must be verified by admin
        profilePhoto: profilePhoto || undefined,
        vehiclePhotos: {
          inside: vehiclePhotosInside,
          outside: vehiclePhotosOutside,
        },
        vehiclePlate: plate,
        driverCategory: driverCategory,
        carBrand: carBrand,
        carLuxury: carLuxury,
        vehicleCategory: vehicleCategory,
        vehicleSubCategory: vehicleSubCategory,
        registrationStep: 'complete',
      };
      onNewNotification({
        type: 'driver_registration',
        title: 'Novo Motorista Pendente',
        message: `O motorista ${newUser.name} enviou documentos para verificação.`,
        userId: newUser.id,
        userName: newUser.name,
      });
      onLogin(newUser);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-white p-8 relative">
      {/* Hidden Admin Entry Point */}
      {(step === 'phone' || step === 'otp') && (
        <div className="absolute top-8 right-8 z-50">
          <button 
            onClick={() => setShowAdminMenu(!showAdminMenu)}
            className="p-2 text-stone-300 hover:text-stone-500 transition-colors"
          >
            <MoreVertical size={24} />
          </button>
          
          <AnimatePresence>
            {showAdminMenu && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 10 }}
                className="absolute right-0 mt-2 w-48 bg-white border border-stone-100 rounded-2xl shadow-2xl p-2 z-50"
              >
                <button 
                  onClick={() => {
                    setRole('admin');
                    setPhone('840000000');
                    setShowAdminMenu(false);
                    
                    // Trigger send OTP flow manually for admin
                    setIsLoading(true);
                    const adminOtp = '0000';
                    setGeneratedOtp(adminOtp);
                    
                    setTimeout(() => {
                      setIsLoading(false);
                      setCountdown(30);
                      setStep('otp');
                      setOtpError(false);
                      // In a real app, this would be an admin-only secure link
                    }, 800);
                  }}
                  className="w-full text-left p-3 hover:bg-stone-50 rounded-xl text-xs font-black uppercase tracking-widest text-stone-600 flex items-center gap-2"
                >
                  <ShieldCheck size={14} className="text-primary-pink" />
                  Painel Gestão
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary-pink rounded-3xl flex items-center justify-center text-white shadow-2xl mx-auto mb-4 transform rotate-3">
            <span className="text-3xl font-extrabold font-display">A</span>
          </div>
          <h1 className="text-2xl font-black text-stone-900 font-display leading-tight">Amafrican</h1>
          <p className="text-[10px] text-stone-400 font-bold uppercase tracking-[0.2em] mt-1">Conectando Moçambique</p>
        </div>

        <AnimatePresence mode="wait">
          {step === 'phone' ? (
            <motion.div 
              key="phone"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="space-y-4">
                <div className="relative flex items-center">
                  <div className="absolute left-4 flex items-center gap-2 pointer-events-none">
                    <span className="text-sm font-black text-stone-900">+258</span>
                    <div className="w-px h-4 bg-stone-200" />
                  </div>
                  <input 
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 9))}
                    placeholder="840000000"
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-2xl pl-16 pr-4 py-5 font-bold outline-none focus:border-primary-pink transition-all"
                  />
                </div>
              </div>

              <button 
                onClick={handleSendOTP}
                disabled={phone.length < 9 || isLoading}
                className="w-full bg-primary-pink text-white py-4 rounded-2xl font-black shadow-xl shadow-pink-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? "Enviando..." : "ENVIAR CÓDIGO"}
                {!isLoading && <ArrowRight size={18} />}
              </button>
            </motion.div>
          ) : step === 'otp' ? (
            <motion.div 
              key="otp"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              <div className="text-center mb-4">
                <p className="text-sm text-stone-500">Enviamos um código para</p>
                <p className="font-bold text-stone-900">{phone}</p>
                <button onClick={() => setStep('phone')} className="text-primary-pink text-xs font-bold mt-1">Alterar número</button>
              </div>

              <div className="relative">
                <LockIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={20} />
                <input 
                  type="text"
                  maxLength={4}
                  value={otp}
                  onChange={(e) => {
                    setOtp(e.target.value);
                    setOtpError(false);
                  }}
                  placeholder="0000"
                  className={cn(
                    "w-full bg-stone-50 border-2 rounded-2xl pl-12 pr-4 py-4 font-bold outline-none font-mono tracking-[1em] text-center transition-all",
                    otpError ? "border-red-500 text-red-500" : "border-stone-100 focus:border-primary-pink"
                  )}
                />
                {otpError && (
                  <p className="text-[10px] text-red-500 font-black uppercase tracking-widest text-center mt-2">
                    Código incorrecto! Tente novamente.
                  </p>
                )}
              </div>

              <button 
                onClick={handleVerifyOTP}
                disabled={otp.length < 4 || isLoading}
                className="w-full bg-primary-red text-white py-4 rounded-2xl font-black shadow-xl shadow-red-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? "Verificando..." : "VERIFICAR E ENTRAR"}
                {!isLoading && <ArrowRight size={18} />}
              </button>

              <div className="text-center">
                <button 
                  onClick={() => countdown === 0 && setCountdown(30)}
                  disabled={countdown > 0}
                  className="text-stone-400 text-xs font-bold flex items-center justify-center gap-2 mx-auto disabled:opacity-50"
                >
                    <MessageSquare size={14} />
                    {countdown > 0 ? `Reenviar código em ${countdown}s` : "Reenviar código agora"}
                </button>
              </div>
            </motion.div>
          ) : step === 'profile_basic' ? (
            <motion.div 
              key="profile_basic"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6 overflow-y-auto max-h-[70vh] px-2 pb-8 scrollbar-hide"
            >
              <div className="text-center">
                <h2 className="text-xl font-black text-stone-900 font-display">Identificação</h2>
                <p className="text-stone-500 text-xs text-balance">Verifique sua identidade para segurança de todos</p>
              </div>

              <div className="flex justify-center mb-4">
                <button 
                  onClick={() => setProfilePhoto("https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400&h=400&fit=crop")}
                  className={cn(
                    "w-24 h-24 rounded-full border-4 border-dashed flex flex-col items-center justify-center transition-all overflow-hidden relative",
                    profilePhoto ? "border-primary-pink bg-pink-50" : "border-stone-200 bg-stone-50"
                  )}
                >
                  {profilePhoto ? (
                    <img src={profilePhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <>
                      <CameraIcon size={24} className="text-stone-400" />
                      <span className="text-[10px] font-bold text-stone-400 uppercase mt-1">Foto Perfil</span>
                    </>
                  )}
                </button>
              </div>

              <div className="space-y-4">
                 <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <input 
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Nome Completo"
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-sm font-bold focus:border-primary-pink outline-none transition-all"
                  />
                </div>
                <div className="relative">
                  <TagIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <input 
                    type="text"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    placeholder="Data de Nascimento (DD/MM/AAAA)"
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-sm font-bold focus:border-primary-pink outline-none transition-all"
                  />
                </div>
                <div className="relative">
                  <FileText className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <input 
                    type="text"
                    value={biNumber}
                    onChange={(e) => setBiNumber(e.target.value.toUpperCase())}
                    placeholder="Número do BI"
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-sm font-bold focus:border-primary-pink outline-none transition-all"
                  />
                </div>
              </div>

              <button 
                onClick={() => setBiPhoto("https://images.unsplash.com/photo-1554224155-1696413565d3?q=80&w=2070&auto=format&fit=crop")}
                className={cn(
                  "w-full aspect-video rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 transition-all overflow-hidden",
                  biPhoto ? "border-emerald-500 bg-emerald-50" : "border-stone-200 bg-stone-50"
                )}
              >
                {biPhoto ? (
                  <div className="relative w-full h-full">
                    <img src={biPhoto} className="w-full h-full object-cover opacity-50" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                      <ShieldCheck className="text-emerald-500" size={32} />
                      <span className="text-xs font-black text-emerald-600 uppercase mt-2">BI Capturado</span>
                    </div>
                  </div>
                ) : (
                  <>
                    <CameraIcon className="text-stone-400" />
                    <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest text-center px-4">Tirar foto do Bilhete de Identidade</span>
                  </>
                )}
              </button>

              <button 
                onClick={handleVerifyBI}
                disabled={!name || !birthDate || !biNumber || !biPhoto || isVerifyingBI}
                className="w-full bg-primary-pink text-white py-4 rounded-2xl font-black shadow-xl shadow-pink-500/20 disabled:opacity-50 flex items-center justify-center gap-2 uppercase tracking-widest text-xs"
              >
                {isVerifyingBI ? "Verificando BI..." : "PRÓXIMO"}
                {!isVerifyingBI && <ArrowRight size={18} />}
              </button>
            </motion.div>
          ) : step === 'profile_docs' ? (
            <motion.div 
              key="profile_docs"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6 overflow-y-auto max-h-[70vh] px-2 pb-8 scrollbar-hide"
            >
              <div className="text-center">
                <h2 className="text-xl font-black text-stone-900 font-display">Documentação</h2>
                <p className="text-stone-500 text-xs">Precisamos da sua carta de condução</p>
              </div>

               <button 
                onClick={() => setLicensePhoto("https://images.unsplash.com/photo-1580674285054-bed31e145f59?w=800")}
                className={cn(
                  "w-full aspect-square rounded-2xl border-2 border-dashed flex flex-col items-center justify-center gap-2 transition-all overflow-hidden",
                  licensePhoto ? "border-emerald-500 bg-emerald-50" : "border-stone-200 bg-stone-50"
                )}
              >
                {licensePhoto ? (
                   <div className="relative w-full h-full">
                    <img src={licensePhoto} className="w-full h-full object-cover opacity-50" referrerPolicy="no-referrer" />
                    <div className="absolute inset-0 flex items-center justify-center flex-col">
                      <ShieldCheck className="text-emerald-500" size={32} />
                      <span className="text-xs font-black text-emerald-600 uppercase mt-2">Carta de Condução Ok</span>
                    </div>
                  </div>
                ) : (
                  <>
                    <CameraIcon className="text-stone-400" />
                    <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest text-center px-8">Foto da Carta de Condução</span>
                  </>
                )}
              </button>

              <button 
                onClick={() => setStep('profile_vehicle')}
                disabled={!licensePhoto}
                className="w-full bg-primary-pink text-white py-4 rounded-2xl font-black shadow-xl shadow-pink-500/20 disabled:opacity-50 flex items-center justify-center gap-2 uppercase tracking-widest text-xs"
              >
                PRÓXIMO
                <ArrowRight size={18} />
              </button>
              <button 
                onClick={() => setStep('profile_basic')}
                className="w-full text-stone-400 py-2 font-bold text-xs uppercase tracking-widest"
              >
                Voltar
              </button>
            </motion.div>
          ) : (
            <motion.div 
              key="profile_vehicle"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6 overflow-y-auto max-h-[70vh] px-2 pb-8 scrollbar-hide"
            >
               <div className="text-center mb-6">
                <h2 className="text-xl font-black text-stone-900 font-display">Meu Veículo</h2>
                <p className="text-stone-500 text-xs">Precisamos de 4 fotos do seu carro</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                {[...Array(2)].map((_, i) => (
                  <button 
                    key={`inside-${i}`}
                    onClick={() => setVehiclePhotosInside(prev => [...prev, "https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?w=400"])}
                    className={cn(
                      "aspect-square rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all overflow-hidden",
                      vehiclePhotosInside[i] ? "border-emerald-500 bg-emerald-50" : "border-stone-200 bg-stone-50"
                    )}
                  >
                    {vehiclePhotosInside[i] ? (
                      <img src={vehiclePhotosInside[i]} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="text-center p-2">
                        <CameraIcon size={20} className="text-stone-400 mx-auto" />
                        <span className="text-[8px] font-bold text-stone-400 uppercase block mt-1">Interior {i+1}</span>
                      </div>
                    )}
                  </button>
                ))}
                {[...Array(2)].map((_, i) => (
                  <button 
                    key={`outside-${i}`}
                    onClick={() => setVehiclePhotosOutside(prev => [...prev, "https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=400"])}
                    className={cn(
                      "aspect-square rounded-2xl border-2 border-dashed flex flex-col items-center justify-center transition-all overflow-hidden",
                      vehiclePhotosOutside[i] ? "border-emerald-500 bg-emerald-50" : "border-stone-200 bg-stone-50"
                    )}
                  >
                    {vehiclePhotosOutside[i] ? (
                      <img src={vehiclePhotosOutside[i]} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    ) : (
                      <div className="text-center p-2">
                        <CameraIcon size={20} className="text-stone-400 mx-auto" />
                        <span className="text-[8px] font-bold text-stone-400 uppercase block mt-1">Exterior {i+1}</span>
                      </div>
                    )}
                  </button>
                ))}
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest px-1">Marca do Carro</p>
                  <input 
                    type="text"
                    value={carBrand}
                    onChange={(e) => setCarBrand(e.target.value)}
                    placeholder="Ex: Toyota Corolla, Mazda..."
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl px-4 py-3 text-sm font-bold outline-none focus:border-primary-pink transition-all"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between px-1">
                    <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest">Nível de Luxo</p>
                    <p className="text-[10px] font-black text-primary-pink uppercase font-display">{carLuxury}%</p>
                  </div>
                  <input 
                    type="range"
                    min="0"
                    max="100"
                    value={carLuxury}
                    onChange={(e) => setCarLuxury(parseInt(e.target.value))}
                    className="w-full h-2 bg-stone-100 rounded-lg appearance-none cursor-pointer accent-primary-pink"
                  />
                  <div className="flex justify-between px-1 text-[8px] font-bold text-stone-400 italic">
                    <span>PADRÃO</span>
                    <span>LUXUOSO</span>
                  </div>
                </div>

                <div className="relative">
                  <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <select 
                    value={driverCategory}
                    onChange={(e) => setDriverCategory(e.target.value as any)}
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-xs font-bold outline-none focus:border-primary-pink transition-all appearance-none uppercase"
                  >
                    <option value="ligeiro">Ligeiro</option>
                    <option value="pesado">Pesado</option>
                    <option value="pesado_profissional">Pesado Profissional</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="relative">
                    <TagIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <select 
                      value={vehicleCategory}
                      onChange={(e) => {
                        const cat = e.target.value as ServiceType;
                        setVehicleCategory(cat);
                        setVehicleSubCategory(VEHICLES[cat][0].id);
                      }}
                      className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-[10px] font-bold outline-none focus:border-primary-pink transition-all appearance-none uppercase"
                    >
                      {SERVICES.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="relative">
                    <Car className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                    <select 
                      value={vehicleSubCategory}
                      onChange={(e) => setVehicleSubCategory(e.target.value)}
                      className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-[10px] font-bold outline-none focus:border-primary-pink transition-all appearance-none uppercase"
                    >
                      {VEHICLES[vehicleCategory].map(v => (
                        <option key={v.id} value={v.id}>{v.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="relative">
                  <FileText className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                  <input 
                    type="text"
                    value={plate}
                    onChange={(e) => setPlate(e.target.value.toUpperCase())}
                    placeholder="Matrícula (Ex: ABC 123 MP)"
                    className="w-full bg-stone-50 border-2 border-stone-100 rounded-xl pl-11 pr-4 py-3 text-sm font-bold outline-none focus:border-primary-pink transition-all"
                  />
                </div>
              </div>

              <button 
                onClick={handleCompleteProfile}
                disabled={!plate || !vehicleSubCategory || vehiclePhotosInside.length < 2 || vehiclePhotosOutside.length < 2 || isLoading}
                className="w-full bg-primary-pink text-white py-4 rounded-2xl font-black shadow-xl shadow-pink-500/20 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? "Concluindo..." : "FINALIZAR REGISTO"}
                {!isLoading && <ArrowRight size={18} />}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-auto text-center space-y-4">
        <p className="text-[10px] text-stone-400 uppercase tracking-widest font-bold">Ao entrar você aceita os nossos termos de serviço</p>
        <div className="flex justify-center gap-4">
          <div className="w-1 bg-primary-pink h-1 rounded-full" />
          <div className="w-1 bg-primary-red h-1 rounded-full" />
          <div className="w-1 bg-primary-yellow h-1 rounded-full" />
        </div>
      </div>
    </div>
  );
}
