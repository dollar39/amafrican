import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Package, HardHat, Truck, MapPin, Search, ChevronRight, Star, Clock, Camera, Phone, MessageSquare, X } from 'lucide-react';
import { SERVICES, VEHICLES, ServiceType, Order, COMMISSION_RATE, UserProfile } from '../types';
import { formatPrice, calculateDistance } from '../lib/utils';
import { MockMap } from './MockMap';
import { cn } from '../lib/utils';

interface ClientAppProps {
  user: UserProfile;
  onOrderCreated: (order: Order) => void;
  activeOrder?: Order;
  onToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export function ClientApp({ user, onOrderCreated, activeOrder, onToast }: ClientAppProps) {
  const [step, setStep] = useState<'home' | 'request' | 'confirm'>('home');
  const [selectedService, setSelectedService] = useState<ServiceType | null>(null);
  const [pickup, setPickup] = useState<{ lat: number; lng: number; address: string } | null>(null);
  const [destination, setDestination] = useState<{ lat: number; lng: number; address: string } | null>(null);
  const [selecting, setSelecting] = useState<'pickup' | 'destination'>('pickup');
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [photo, setPhoto] = useState<string | null>(null);
  const [cargoDesc, setCargoDesc] = useState('');

  const reset = () => {
    setStep('home');
    setSelectedService(null);
    setPickup(null);
    setDestination(null);
    setSelectedVehicle(null);
    setPhoto(null);
    setCargoDesc('');
  };

  const handleCreateOrder = () => {
    if (!selectedService || !pickup || !destination || !selectedVehicle) return;
    if ((selectedService === 'merchandise' || selectedService === 'materials') && (!cargoDesc || !photo)) {
      onToast("Anexe uma foto e descrição da carga.", 'error');
      return;
    }
    
    const vehicle = VEHICLES[selectedService].find(v => v.id === selectedVehicle);
    const dist = calculateDistance(pickup.lat, pickup.lng, destination.lat, destination.lng);
    
    // Luxury multiplier calculation: Base price + random luxury (simulated since user picks car later if needed)
    // Or we apply a standard luxury tier. Let's apply a 50% average luxury increase for transparency.
    let basePrice = (vehicle?.basePrice || 0) + (dist * (vehicle?.pricePerKm || 0));
    if (selectedService === 'people') {
       basePrice = basePrice * 1.4; // Assuming 40% avg luxury increase for preview
    }
    const roundedPrice = Math.round(basePrice);
    const commission = Math.round(roundedPrice * COMMISSION_RATE);

    const order: Order = {
      id: Math.random().toString(36).substr(2, 9),
      serviceType: selectedService,
      vehicleType: selectedVehicle,
      status: 'pending',
      pickup,
      destination,
      price: roundedPrice,
      commission: commission,
      customerId: user.id,
      customerName: user.name,
      customerPhone: user.phone,
      cargoDescription: cargoDesc,
      cargoPhoto: photo || undefined,
      createdAt: Date.now(),
    };

    onOrderCreated(order);
    reset();
  };

  if (activeOrder) {
    return (
      <div className="flex flex-col h-full bg-white">
        <div className="h-2/3 relative">
          <MockMap pickup={activeOrder.pickup} destination={activeOrder.destination} />
          <div className="absolute top-4 left-4 right-4 bg-white p-4 rounded-xl shadow-lg flex items-center gap-3">
            <div className="w-12 h-12 bg-primary-yellow rounded-full flex items-center justify-center">
              <Truck className="w-6 h-6 text-primary-brown" />
            </div>
            <div className="flex-1">
              <p className="text-xs text-gray-500 uppercase font-bold">Estado do Pedido</p>
              <p className="font-bold">
                {activeOrder.status === 'pending' && 'À procura de motorista...'}
                {activeOrder.status === 'accepted' && 'Motorista a caminho'}
                {activeOrder.status === 'in_progress' && 'Em viagem'}
              </p>
            </div>
          </div>
        </div>
        <div className="flex-1 p-6 bg-white rounded-t-3xl -mt-6 z-10 shadow-up">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-bold">Viagem em curso</h3>
              <p className="text-sm text-gray-500">{activeOrder.vehicleType} • {formatPrice(activeOrder.price)}</p>
            </div>
            <div className="flex gap-2">
              <button className="p-3 bg-green-100 text-green-700 rounded-full">
                <Phone className="w-5 h-5" />
              </button>
              <button className="p-3 bg-blue-100 text-blue-700 rounded-full">
                <MessageSquare className="w-5 h-5" />
              </button>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex gap-3">
              <MapPin className="w-5 h-5 text-green-600 flex-shrink-0" />
              <p className="text-sm">{activeOrder.pickup.address}</p>
            </div>
            <div className="flex gap-3">
              <MapPin className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-sm">{activeOrder.destination.address}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <AnimatePresence mode="wait">
        {step === 'home' && (
          <motion.div 
            key="home"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="p-6 space-y-6 overflow-y-auto flex-1"
          >
            <div className="flex items-center justify-between mb-8">
              <div className="flex-1" />
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-primary-pink rounded-xl flex items-center justify-center text-white shadow-lg transform -rotate-3 transition-transform hover:rotate-0">
                  <span className="text-xl font-bold font-display">A</span>
                </div>
                <div>
                  <h1 className="text-xl font-extrabold text-stone-900 font-display tracking-tight leading-none">Amafrican</h1>
                  <p className="text-[10px] text-primary-red font-bold uppercase tracking-widest text-center">Moçambique</p>
                </div>
              </div>
              <div className="flex-1 flex justify-end">
                <div className="w-10 h-10 bg-stone-50 rounded-full flex items-center justify-center font-bold text-stone-400 shadow-sm text-sm border border-stone-100">
                  <User size={18} />
                </div>
              </div>
            </div>

            <div className="text-center mb-8">
               <h2 className="text-3xl font-black text-stone-900 font-display tracking-tight leading-tight">Escolha o seu <br/> destino</h2>
               <p className="text-[10px] text-stone-400 font-bold uppercase tracking-[0.3em] mt-2">Conectando você a tudo</p>
            </div>

            <div className="bg-primary-pink rounded-[40px] p-8 text-center text-white overflow-hidden relative shadow-2xl mb-8">
              <Truck className="absolute -bottom-8 -left-8 w-48 h-48 opacity-10 rotate-12" />
              <div className="relative z-10 flex flex-col items-center">
                <div className="bg-white/20 p-3 rounded-2xl mb-4 backdrop-blur-md">
                  <Package className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-black mb-2 font-display uppercase tracking-tight">Logística Total</h2>
                <p className="text-[10px] text-pink-100 font-bold uppercase tracking-widest mb-6 max-w-[200px]">Transporte de pessoas, encomendas e materiais de construção</p>
                <button 
                  onClick={() => setStep('request')}
                  className="bg-white text-primary-pink px-8 py-3 rounded-2xl text-[10px] font-black shadow-lg hover:bg-stone-50 transition-all uppercase tracking-[0.2em] active:scale-95"
                >
                  Iniciar Viagem
                </button>
              </div>
            </div>

            <section>
              <div className="grid grid-cols-1 gap-4">
                {SERVICES.map(s => {
                  const Icon = { User, Package, HardHat, Truck }[s.icon] as any;
                  return (
                    <motion.button
                      key={s.id}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => {
                        setSelectedService(s.id as ServiceType);
                        setStep('request');
                      }}
                      className="bg-white p-6 rounded-[32px] border border-stone-100 shadow-sm hover:shadow-md transition-all flex items-center gap-6 active:scale-95 duration-75 group"
                    >
                      <div className={cn("w-16 h-16 rounded-3xl text-white shadow-lg flex items-center justify-center transition-transform group-hover:scale-110", s.color)}>
                        <Icon size={28} />
                      </div>
                      <div className="text-left">
                        <span className="font-black text-sm text-stone-800 uppercase tracking-tight">{s.name}</span>
                        <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest mt-1">Serviço disponível 24h</p>
                      </div>
                    </motion.button>
                  );
                })}
              </div>
            </section>

            <section>
              <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider mb-4">Pedidos recentes</h3>
              <div className="space-y-3">
                {[1, 2].map(i => (
                  <div key={i} className="flex items-center gap-4 bg-stone-50 p-3 rounded-xl border border-stone-100">
                    <div className="w-10 h-10 bg-stone-200 rounded-lg flex items-center justify-center">
                      <Clock className="w-5 h-5 text-stone-400" />
                    </div>
                    <div>
                      <p className="text-sm font-bold">Maputo Shopping Center</p>
                      <p className="text-xs text-gray-500">24 Abr, 14:20 • Pago em dinheiro</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </motion.div>
        )}

        {step === 'request' && (
          <motion.div 
            key="request"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col h-full bg-white relative"
          >
            <div className="absolute top-4 left-4 z-20">
              <button 
                onClick={() => setStep('home')}
                className="bg-white p-2 rounded-full shadow-lg border border-stone-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1">
              <MockMap 
                pickup={pickup || undefined} 
                destination={destination || undefined}
                onLocationSelect={(lat, lng) => {
                  const addr = `Localização ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
                  if (selecting === 'pickup') {
                    setPickup({ lat, lng, address: addr });
                    setSelecting('destination');
                  } else {
                    setDestination({ lat, lng, address: addr });
                  }
                }}
              />
            </div>

            <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 w-[90%] max-w-sm space-y-2">
              <div 
                onClick={() => setSelecting('pickup')}
                className={cn(
                  "bg-white p-3 rounded-xl shadow-md border-2 transition-all flex items-center gap-3 cursor-pointer",
                  selecting === 'pickup' ? "border-primary-green" : "border-slate-100"
                )}
              >
                <MapPin className="w-5 h-5 text-green-600" />
                <span className="text-sm truncate">{pickup?.address || 'Definir ponto de recolha'}</span>
              </div>
              <div 
                onClick={() => setSelecting('destination')}
                className={cn(
                  "bg-white p-3 rounded-xl shadow-md border-2 transition-all flex items-center gap-3 cursor-pointer",
                  selecting === 'destination' ? "border-primary-green text-black" : "border-slate-100 text-gray-400"
                )}
              >
                <MapPin className="w-5 h-5 text-red-600" />
                <span className="text-sm truncate">{destination?.address || 'Definir destino'}</span>
              </div>
            </div>

            {pickup && destination && (
              <motion.div 
                initial={{ y: 100 }}
                animate={{ y: 0 }}
                className="bg-white p-6 rounded-t-3xl shadow-up z-30"
              >
                <h3 className="font-bold mb-4">Selecione o Veículo</h3>
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {selectedService && VEHICLES[selectedService].map(v => (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVehicle(v.id)}
                      className={cn(
                        "flex-shrink-0 border-2 rounded-2xl p-4 transition-all text-center flex flex-col items-center justify-center",
                        selectedVehicle === v.id ? "border-primary-pink bg-pink-50 text-primary-pink" : "border-stone-100 text-stone-400"
                      )}
                    >
                      <Truck className="w-8 h-8 mb-2" />
                      <p className="font-black text-[10px] uppercase tracking-widest leading-none mb-1">{v.name}</p>
                      <p className="text-[9px] font-bold opacity-60 mb-2">
                        {selectedService === 'people' ? "Até +80% Luxo" : "Mín. 65% Luxo"}
                      </p>
                      <p className="text-base font-black">
                        {formatPrice(v.basePrice + (calculateDistance(pickup.lat, pickup.lng, destination.lat, destination.lng) * v.pricePerKm))}
                      </p>
                    </button>
                  ))}
                </div>

                {(selectedService === 'merchandise' || selectedService === 'materials') && (
                  <div className="mt-4 space-y-4">
                    <div className="space-y-1">
                      <p className="text-[10px] font-black text-stone-400 uppercase tracking-widest px-1">O que vai transportar?</p>
                      <input 
                        type="text"
                        value={cargoDesc}
                        onChange={(e) => setCargoDesc(e.target.value)}
                        placeholder="Ex: 5 sacos de arroz, 1 geleira..."
                        className="w-full bg-stone-50 border-2 border-stone-100 rounded-2xl px-5 py-3 text-sm font-bold focus:border-primary-pink outline-none transition-colors"
                      />
                      <p className="text-[9px] text-stone-400 font-medium px-1 italic">
                        {selectedService === 'merchandise' 
                          ? "Aceitamos: Sacos de supermercado, Produtos de loja, Roupas, Sapatos, Encomendas online, Documentos, Acessorios e electronicos."
                          : "Aceitamos: Mobilia, Material de construcao, Materiais de obra grandes quantidades."}
                      </p>
                    </div>

                    <button 
                      onClick={() => setPhoto("https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=400")}
                      className={cn(
                        "w-full p-4 rounded-2xl border-2 border-dashed flex items-center justify-center gap-3 transition-all",
                        photo ? "border-emerald-500 bg-emerald-50 text-emerald-600" : "border-stone-200 text-stone-400 hover:bg-stone-50"
                      )}
                    >
                      {photo ? (
                        <>
                          <div className="w-10 h-10 rounded-lg overflow-hidden border border-emerald-200">
                             <img src={photo} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          </div>
                          <span className="text-xs font-black uppercase">Foto Anexada</span>
                        </>
                      ) : (
                        <>
                          <Camera size={20} />
                          <span className="text-xs font-black uppercase tracking-widest">Tirar foto da carga</span>
                        </>
                      )}
                    </button>
                  </div>
                )}

                <button 
                  onClick={handleCreateOrder}
                  disabled={!selectedVehicle}
                  className="w-full bg-primary-pink text-white py-4 rounded-2xl font-black mt-6 shadow-xl shadow-pink-900/20 disabled:opacity-50 active:scale-95 transition-all uppercase tracking-wider font-display"
                >
                  Confirmar Pedido
                </button>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
