import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, CreditCard, Save, PieChart, TrendingUp, Users, Key as KeyIcon, Lock as LockIcon, Settings as SettingsIcon, Phone, Search, Check, X, FileText, Camera, Car, CheckCircle, Bell } from 'lucide-react';
import { Order, DEFAULT_ADMIN_PIN, PIN_CHANGE_COOLDOWN, PaymentTransaction, UserProfile, AdminNotification } from '../types';
import { cn, formatPrice } from '../lib/utils';

interface AdminPanelProps {
  orders: Order[];
  transactions: PaymentTransaction[];
  users: UserProfile[];
  notifications: AdminNotification[];
  onNotificationsRead: () => void;
  onVerifyDriver: (userId: string) => void;
  onRewardUser: (userId: string, amount: number) => void;
  onRemoveUser: (userId: string) => void;
  supportNumber: string;
  onUpdateSupport: (num: string) => void;
  onToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export function AdminPanel({ orders, transactions, users, notifications, onNotificationsRead, onVerifyDriver, onRewardUser, onRemoveUser, supportNumber, onUpdateSupport, onToast }: AdminPanelProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'finance' | 'verifications' | 'users' | 'settings'>('dashboard');
  const [showNotifications, setShowNotifications] = useState(false);
  const [accountNumber, setAccountNumber] = useState('');
  const [payoutMethod, setPayoutMethod] = useState('mpesa');
  const [isSaved, setIsSaved] = useState(false);
  const [rewardAmount, setRewardAmount] = useState<string>('50');
  const [pin, setPin] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [error, setError] = useState(false);
  
  // PIN management
  const [storedPin, setStoredPin] = useState(DEFAULT_ADMIN_PIN);
  const [pinUpdatedAt, setPinUpdatedAt] = useState(0);
  const [newPin, setNewPin] = useState('');
  const [showConfig, setShowConfig] = useState(false);

  useEffect(() => {
    const savedAcc = localStorage.getItem('amafrican_admin_acc');
    if (savedAcc) setAccountNumber(savedAcc);

    const savedPin = localStorage.getItem('amafrican_admin_pin');
    const savedPinDate = localStorage.getItem('amafrican_admin_pin_date');
    if (savedPin) setStoredPin(savedPin);
    if (savedPinDate) setPinUpdatedAt(parseInt(savedPinDate));
  }, []);

  const handleVerifyPin = () => {
    if (pin === storedPin) {
      setIsAuthorized(true);
      setError(false);
    } else {
      setError(true);
      setPin('');
    }
  };

  const handleUpdatePin = () => {
    if (newPin.length !== 6) return;
    const now = Date.now();
    const daysRemaining = Math.ceil((PIN_CHANGE_COOLDOWN - (now - pinUpdatedAt)) / (1000 * 60 * 60 * 24));
    
    if (pinUpdatedAt > 0 && now - pinUpdatedAt < PIN_CHANGE_COOLDOWN) {
      onToast(`Mude o código em ${daysRemaining} dias.`, 'info');
      return;
    }

    localStorage.setItem('amafrican_admin_pin', newPin);
    localStorage.setItem('amafrican_admin_pin_date', now.toString());
    setStoredPin(newPin);
    setPinUpdatedAt(now);
    setNewPin('');
    onToast('PIN alterado com sucesso!');
  };

  const handleSave = () => {
    localStorage.setItem('amafrican_admin_acc', accountNumber);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const totalRevenue = orders.filter(o => o.status === 'completed').reduce((acc, o) => acc + o.price, 0);
  const totalCommission = transactions.filter(t => t.type === 'commission').reduce((acc, t) => acc + t.amount, 0);
  const totalSubs = transactions.filter(t => t.type === 'subscription').reduce((acc, t) => acc + t.amount, 0);

  const pendingDrivers = users.filter(u => u.role === 'driver' && !u.isVerified);

  if (!isAuthorized) {
    return (
      <div className="flex flex-col h-full bg-slate-900 items-center justify-center p-8 text-center">
        <div className="w-20 h-20 bg-primary-red rounded-3xl flex items-center justify-center text-white shadow-2xl mb-8 transform rotate-3">
          <ShieldCheck size={40} />
        </div>
        <h2 className="text-2xl font-black text-white mb-2 font-display">Acesso Restrito</h2>
        <p className="text-stone-400 text-sm mb-8">Insira o código de 6 dígitos para aceder ao painel do criador.</p>
        
        <div className="w-full max-w-xs space-y-4">
          <div className="relative">
            <KeyIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-500" size={20} />
            <input 
              type="password"
              maxLength={6}
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="CÓDIGO DE ACESSO"
              className={cn(
                "w-full bg-slate-800 border-2 rounded-2xl pl-12 pr-4 py-4 text-white font-black tracking-[0.5em] text-center outline-none transition-all",
                error ? "border-red-500" : "border-slate-700 focus:border-primary-pink"
              )}
            />
          </div>
          <button 
            onClick={handleVerifyPin}
            className="w-full bg-primary-pink text-white py-4 rounded-2xl font-black shadow-xl shadow-pink-500/20 active:scale-95 transition-all"
          >
            ENTRAR NO PAINEL
          </button>
          {error && <p className="text-red-500 text-xs font-bold uppercase tracking-widest mt-2">Código Incorrecto!</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 overflow-hidden">
      {/* Header */}
      <div className="p-6 bg-white border-b border-slate-100 flex items-center justify-between z-10 shadow-sm shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary-pink rounded-xl flex items-center justify-center text-white shadow-lg transform -rotate-3">
            <ShieldCheck size={24} />
          </div>
          <div>
            <h1 className="text-lg font-black text-slate-900 leading-none font-display">Gestão Amafrican</h1>
            <p className="text-[9px] text-primary-red font-bold uppercase tracking-widest mt-1">Admin Portal</p>
          </div>
        </div>

        <div className="relative">
          <button 
            onClick={() => {
              setShowNotifications(!showNotifications);
              if (!showNotifications) onNotificationsRead();
            }}
            className="p-2 text-stone-400 hover:text-primary-pink transition-colors relative"
          >
            <Bell size={20} />
            {notifications.filter(n => !n.read).length > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-primary-red rounded-full border-2 border-white" />
            )}
          </button>

          <AnimatePresence>
            {showNotifications && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowNotifications(false)}
                />
                <motion.div 
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-72 bg-white border border-stone-100 rounded-3xl shadow-2xl z-50 overflow-hidden"
                >
                  <div className="p-4 bg-stone-50 border-b border-stone-100 flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-widest text-stone-900">Notificações</span>
                    <span className="text-[8px] font-black text-primary-pink uppercase">{notifications.length} total</span>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-8 text-center text-[10px] font-bold text-stone-400 italic">
                        Nenhuma notificação por agora.
                      </div>
                    ) : (
                      notifications.map(n => (
                        <div 
                          key={n.id} 
                          className={cn(
                            "p-4 border-b border-stone-50 transition-colors cursor-default",
                            !n.read ? "bg-pink-50/30" : "bg-white hover:bg-stone-50"
                          )}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-primary-pink" />
                            <p className="text-[10px] font-black text-stone-900 uppercase">{n.title}</p>
                          </div>
                          <p className="text-[10px] text-stone-500 leading-tight mb-2">{n.message}</p>
                          <p className="text-[8px] text-stone-400 font-bold uppercase">{new Date(n.timestamp).toLocaleDateString()} • {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                        </div>
                      ))
                    )}
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Tabs Nav */}
      <div className="flex bg-white px-6 border-b border-stone-100 shrink-0">
        {[
          { id: 'dashboard', label: 'Início', icon: TrendingUp },
          { id: 'verifications', label: 'Validar', icon: ShieldCheck, badge: pendingDrivers.length },
          { id: 'users', label: 'Utilizadores', icon: Users },
          { id: 'finance', label: 'Finanças', icon: CreditCard },
          { id: 'settings', label: 'Apoio', icon: SettingsIcon },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={cn(
              "flex-1 py-4 flex flex-col items-center gap-1 border-b-4 transition-all relative",
              activeTab === tab.id ? "border-primary-pink text-primary-pink" : "border-transparent text-slate-400"
            )}
          >
            <tab.icon size={18} />
            <span className="text-[8px] font-black uppercase tracking-widest leading-none">{tab.label}</span>
            {tab.badge ? (
              <span className="absolute top-2 right-1/4 bg-primary-red text-white text-[8px] font-black w-4 h-4 rounded-full flex items-center justify-center shadow-lg border-2 border-white">
                {tab.badge}
              </span>
            ) : null}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6 pb-20">
        {activeTab === 'dashboard' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-900 p-5 rounded-3xl text-white shadow-xl col-span-2 relative overflow-hidden group">
                <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-primary-pink/20 rounded-full blur-3xl group-hover:bg-primary-pink/30 transition-all" />
                <div className="relative">
                  <div className="flex items-center gap-2 text-primary-pink mb-2">
                    <TrendingUp size={14} />
                    <span className="text-[10px] font-black uppercase tracking-widest opacity-70">Saldo do Sistema</span>
                  </div>
                  <p className="text-4xl font-black">{formatPrice(totalCommission + totalSubs)}</p>
                  <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-[8px] text-stone-400 font-bold uppercase tracking-widest">Motoristas</p>
                      <p className="text-xs font-black">{users.filter(u => u.role === 'driver').length}</p>
                    </div>
                    <div>
                      <p className="text-[8px] text-stone-400 font-bold uppercase tracking-widest">Viagens</p>
                      <p className="text-xs font-black">{orders.filter(o => o.status === 'completed').length}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2 text-primary-pink mb-2">
                  <PieChart size={14} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Comissões</span>
                </div>
                <p className="text-xl font-black text-slate-900">{formatPrice(totalCommission)}</p>
              </div>
              <div className="bg-white p-5 rounded-3xl border border-slate-100 shadow-sm">
                <div className="flex items-center gap-2 text-primary-pink mb-2">
                  <CreditCard size={14} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Recargas</span>
                </div>
                <p className="text-xl font-black text-slate-900">{formatPrice(totalSubs)}</p>
              </div>
            </div>

            <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-4">
               <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Users className="text-primary-pink" size={20} />
                    <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Motoristas Activos</h3>
                  </div>
                  <span className="text-[10px] font-black text-slate-400">{users.filter(u => u.role === 'driver').length} total</span>
               </div>
               <div className="space-y-3">
                 {users.filter(u => u.role === 'driver').slice(0, 5).map(u => (
                   <div key={u.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100">
                     <div className="flex items-center gap-3">
                       <div className="w-8 h-8 rounded-full bg-stone-200 overflow-hidden border border-stone-300">
                         {u.profilePhoto && <img src={u.profilePhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />}
                       </div>
                       <div>
                         <p className="text-[10px] font-black text-stone-900 uppercase truncate max-w-[100px]">{u.name}</p>
                         <p className="text-[8px] text-stone-400 font-bold">{u.phone}</p>
                       </div>
                     </div>
                     <div className={cn(
                       "text-[8px] font-black px-2 py-1 rounded-full uppercase tracking-widest",
                       u.isVerified ? "bg-emerald-100 text-emerald-600" : "bg-red-100 text-red-600"
                     )}>
                       {u.isVerified ? 'Verificado' : 'Pendente'}
                     </div>
                   </div>
                 ))}
               </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'verifications' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="text-center mb-4">
              <h2 className="text-xl font-black text-slate-900 font-display">Fila de Validação</h2>
              <p className="text-stone-500 text-xs text-balance">Verifique os documentos e aprove novos motoristas</p>
            </div>

            {pendingDrivers.length === 0 ? (
              <div className="py-20 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto text-emerald-500">
                  <Check size={32} />
                </div>
                <p className="text-sm font-bold text-slate-400">Nenhum motorista pendente.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {pendingDrivers.map(u => (
                  <div key={u.id} className="bg-white rounded-[32px] border border-slate-100 shadow-xl overflow-hidden">
                    <div className="p-5 flex items-center gap-4 border-b border-slate-50">
                      <div className="w-12 h-12 rounded-2xl bg-stone-100 overflow-hidden border border-stone-200">
                        {u.profilePhoto && <img src={u.profilePhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />}
                      </div>
                      <div className="flex-1">
                        <h4 className="text-sm font-black text-slate-900 uppercase">{u.name}</h4>
                        <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{u.phone} • {u.vehiclePlate}</p>
                      </div>
                    </div>
                    
                    <div className="p-5 bg-slate-50/50 space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-2">
                           <p className="text-[8px] text-stone-400 font-black uppercase tracking-widest flex items-center gap-1">
                             <FileText size={8} className="text-primary-pink" /> BI Frontal
                           </p>
                           <div className="aspect-video bg-stone-200 rounded-xl overflow-hidden border border-stone-300 relative group">
                             {u.biPhoto ? <img src={u.biPhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <div className="w-full h-full flex items-center justify-center"><Camera size={12} className="text-stone-400" /></div>}
                           </div>
                        </div>
                        <div className="space-y-2">
                           <p className="text-[8px] text-stone-400 font-black uppercase tracking-widest flex items-center gap-1">
                             <CheckCircle size={8} className="text-primary-pink" /> Carta
                           </p>
                           <div className="aspect-video bg-stone-200 rounded-xl overflow-hidden border border-stone-300 relative">
                             {u.licensePhoto ? <img src={u.licensePhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <div className="w-full h-full flex items-center justify-center"><Camera size={12} className="text-stone-400" /></div>}
                           </div>
                        </div>
                      </div>

                      <div className="space-y-2">
                         <p className="text-[8px] text-stone-400 font-black uppercase tracking-widest flex items-center gap-1">
                           <Car size={8} className="text-primary-pink" /> Veículo ({u.vehicleSubCategory})
                         </p>
                         <div className="grid grid-cols-4 gap-2">
                            {u.vehiclePhotos?.outside.map((url, i) => (
                              <div key={i} className="aspect-square bg-stone-200 rounded-lg overflow-hidden border border-stone-300">
                                <img src={url} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                              </div>
                            ))}
                         </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 pt-2">
                         <button className="flex items-center justify-center gap-2 py-3 bg-white border border-stone-200 rounded-xl text-stone-400 text-[10px] font-black uppercase tracking-widest hover:text-red-500 hover:border-red-100 transition-colors">
                           <X size={14} /> Rejeitar
                         </button>
                         <button 
                           onClick={() => onVerifyDriver(u.id)}
                           className="flex items-center justify-center gap-2 py-3 bg-emerald-500 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
                         >
                           <Check size={14} /> Aprovar
                         </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}

        {activeTab === 'users' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-black text-slate-900 font-display">Gestão de Utilizadores</h2>
              <div className="flex items-center gap-2 bg-white px-3 py-1 rounded-full border border-stone-100 shadow-sm">
                <span className="text-[10px] font-black text-stone-400 uppercase">Bónus Admin:</span>
                <input 
                  type="number"
                  value={rewardAmount}
                  onChange={(e) => setRewardAmount(e.target.value)}
                  className="w-12 text-center text-xs font-black text-primary-pink outline-none"
                />
                <span className="text-[10px] font-black text-stone-400 uppercase">MT</span>
              </div>
            </div>

            <div className="space-y-4">
              {users.filter(u => u.role !== 'admin').map(u => (
                <div key={u.id} className="bg-white p-5 rounded-[32px] border border-stone-100 shadow-sm space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-stone-100 overflow-hidden border border-stone-200">
                        {u.profilePhoto && <img src={u.profilePhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />}
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-slate-900 uppercase">{u.name}</h4>
                        <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">{u.phone} • {u.role === 'driver' ? 'Motorista' : 'Cliente'}</p>
                      </div>
                    </div>
                    {u.role === 'driver' && (
                      <div className="text-right">
                        <div className="flex gap-1 justify-end">
                          {[1,2,3,4,5].map(i => (
                            <span key={i} className={cn("text-[10px]", i <= Math.round(u.rating || 0) ? "text-primary-yellow" : "text-stone-200")}>★</span>
                          ))}
                        </div>
                        <p className="text-[8px] text-stone-400 font-bold uppercase mt-1">Saldo: {formatPrice(u.bonusBalance || 0)}</p>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3 pt-2">
                    {u.role === 'driver' && (
                      <button 
                        onClick={() => {
                          const amt = parseInt(rewardAmount);
                          if (amt > 0 && amt <= 200) {
                            onRewardUser(u.id, amt);
                            onToast(`Bónus de ${formatPrice(amt)} enviado!`);
                          } else {
                            onToast("Bónus entre 1 MT e 200 MT", 'error');
                          }
                        }}
                        className="flex items-center justify-center gap-2 py-3 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all"
                      >
                        <PieChart size={14} /> Dar Bónus
                      </button>
                    )}
                    <button 
                      onClick={() => onRemoveUser(u.id)}
                      className={cn(
                        "flex items-center justify-center gap-2 py-3 bg-red-50 text-red-600 border border-red-100 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all",
                        u.role !== 'driver' && "col-span-2"
                      )}
                    >
                      <X size={14} /> Banir Utilizador
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {activeTab === 'finance' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <section className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <CreditCard className="text-primary-pink" size={20} />
                  <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Histórico de Pagamentos</h3>
                </div>
                <span className="text-[10px] font-black text-slate-400">{transactions.length} items</span>
              </div>
              
              <div className="space-y-3">
                {transactions.map(t => (
                  <div key={t.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-2xl border border-slate-100">
                    <div>
                      <p className="text-[10px] font-black text-stone-900 uppercase truncate max-w-[120px]">{t.userName}</p>
                      <p className="text-[8px] text-stone-400 font-bold uppercase tracking-tighter">{t.type === 'subscription' ? 'Recarga Mensal' : 'Comissão Viagem'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-black text-emerald-600">+{formatPrice(t.amount)}</p>
                      <p className="text-[8px] text-stone-400 font-bold">{new Date(t.timestamp).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
                {transactions.length === 0 && <p className="text-center text-xs text-stone-400 py-4 italic">Nenhum pagamento registado.</p>}
              </div>
            </section>

            <section className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <CreditCard className="text-primary-pink" size={20} />
                <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Payout Criador</h3>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <button 
                    onClick={() => setPayoutMethod('mpesa')}
                    className={cn(
                      "py-3 rounded-xl font-bold text-xs transition-all border-2",
                      payoutMethod === 'mpesa' ? "border-primary-yellow bg-yellow-50 text-stone-900" : "border-slate-100 text-slate-400"
                    )}
                  >
                    M-Pesa
                  </button>
                  <button 
                    onClick={() => setPayoutMethod('bank')}
                    className={cn(
                      "py-3 rounded-xl font-bold text-xs transition-all border-2",
                      payoutMethod === 'bank' ? "border-primary-yellow bg-yellow-50 text-stone-900" : "border-slate-100 text-slate-400"
                    )}
                  >
                    Conta Bancária
                  </button>
                </div>

                <input 
                  type="text" 
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder={payoutMethod === 'mpesa' ? "84 / 85 XXX XXXX" : "IBAN / Numero de Conta"}
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-sm font-bold focus:border-primary-pink outline-none transition-colors"
                />

                <button 
                  onClick={handleSave}
                  className={cn(
                    "w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2",
                    isSaved ? "bg-emerald-500 text-white" : "bg-primary-pink text-white shadow-lg shadow-pink-500/20"
                  )}
                >
                  {isSaved ? <Check size={16} /> : null}
                  {isSaved ? "GUARDADO" : "GUARDAR CONFIGURAÇÃO"}
                </button>
              </div>
            </section>
          </motion.div>
        )}

        {activeTab === 'settings' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <section className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm space-y-4">
               <div className="space-y-4">
                <div className="flex items-center gap-2 mb-1">
                  <Phone className="text-primary-pink" size={20} />
                  <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Número de Apoio</h3>
                </div>
                <input 
                  type="text"
                  value={supportNumber}
                  onChange={(e) => onUpdateSupport(e.target.value)}
                  placeholder="Número de Apoio"
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-5 py-3 text-sm font-bold focus:border-primary-pink outline-none transition-colors"
                />
              </div>

              <div className="flex items-center gap-2 pt-4 border-t border-slate-50">
                <LockIcon className="text-primary-pink" size={20} />
                <h3 className="font-black text-slate-800 uppercase text-xs tracking-widest">Segurança do Painel</h3>
              </div>
              <div className="space-y-3">
                <input 
                  type="password"
                  maxLength={6}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value)}
                  placeholder="NOVO CÓDIGO (6 DÍGITOS)"
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl px-5 py-4 text-sm font-bold focus:border-primary-pink outline-none transition-colors text-center tracking-[0.5em]"
                />
                <button 
                  onClick={handleUpdatePin}
                  disabled={newPin.length !== 6}
                  className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest disabled:opacity-50"
                >
                  DEFINIR NOVO CÓDIGO
                </button>
              </div>
            </section>
          </motion.div>
        )}
      </div>

      <div className="p-6 bg-pink-50 border-t border-pink-100 italic text-primary-red text-[10px] text-center font-bold px-10 leading-tight">
        "A comissão de 15% é aplicada automaticamente em cada viagem concluída e será transferida para a sua conta configurada."
      </div>
    </div>
  );
}
