import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Navigation } from 'lucide-react';
import { MAPUTO_CENTER } from '../types';

interface MockMapProps {
  onLocationSelect?: (lat: number, lng: number) => void;
  pickup?: { lat: number; lng: number };
  destination?: { lat: number; lng: number };
  drivers?: Array<{ id: string; lat: number; lng: number }>;
}

export function MockMap({ onLocationSelect, pickup, destination, drivers }: MockMapProps) {
  const [userPos, setUserPos] = useState(MAPUTO_CENTER);
  const [scale] = useState(500); // Simple coordinate to pixel scale

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
        setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
      });
    }
  }, []);

  const toPx = (coords: { lat: number; lng: number }) => {
    const x = (coords.lng - MAPUTO_CENTER.lng) * scale * 2 + 150;
    const y = (MAPUTO_CENTER.lat - coords.lat) * scale * 2 + 150;
    return { x, y };
  };

  return (
    <div className="relative w-full h-full bg-slate-100 overflow-hidden cursor-crosshair" 
         onClick={(e) => {
           const rect = e.currentTarget.getBoundingClientRect();
           const x = e.clientX - rect.left;
           const y = e.clientY - rect.top;
           const lng = MAPUTO_CENTER.lng + (x - 150) / (scale * 2);
           const lat = MAPUTO_CENTER.lat - (y - 150) / (scale * 2);
           onLocationSelect?.(lat, lng);
         }}>
      {/* City Grid Mock */}
      <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 300 300">
        <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
          <path d="M 30 0 L 0 0 0 30" fill="none" stroke="gray" strokeWidth="0.5"/>
        </pattern>
        <rect width="100%" height="100%" fill="url(#grid)" />
        {/* Mock Roads */}
        <path d="M 0 150 L 300 150" stroke="gray" strokeWidth="2" opacity="0.5" />
        <path d="M 150 0 L 150 300" stroke="gray" strokeWidth="2" opacity="0.5" />
        <circle cx="150" cy="150" r="10" fill="gray" opacity="0.2" />
      </svg>
      
      <div className="absolute top-4 left-4 bg-white/90 px-3 py-1 rounded-full text-[10px] font-bold shadow-sm border border-slate-200">
        MAPUTO, MOÇAMBIQUE
      </div>

      {drivers?.map(d => {
        const p = toPx(d);
        return (
          <motion.div 
            key={d.id}
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1, x: p.x, y: p.y }}
            className="absolute -ml-2 -mt-2"
          >
            <Navigation className="w-4 h-4 text-green-600 rotate-45" fill="currentColor" />
          </motion.div>
        );
      })}

      {pickup && (
        <div className="absolute" style={{ left: toPx(pickup).x, top: toPx(pickup).y }}>
          <div className="relative -ml-3 -mt-6">
            <MapPin className="w-6 h-6 text-green-600" />
          </div>
        </div>
      )}

      {destination && (
        <div className="absolute" style={{ left: toPx(destination).x, top: toPx(destination).y }}>
          <div className="relative -ml-3 -mt-6">
            <MapPin className="w-6 h-6 text-red-600" />
          </div>
        </div>
      )}

      {/* Origin/Current Pos Marker */}
      <div className="absolute" style={{ left: toPx(userPos).x, top: toPx(userPos).y }}>
        <div className="w-3 h-3 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse -ml-1.5 -mt-1.5" />
      </div>
    </div>
  );
}
