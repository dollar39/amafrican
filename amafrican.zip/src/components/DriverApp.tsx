import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Truck, MapPin, CheckCircle, Navigation, Phone, MessageSquare, DollarSign, Power, X, Search, User as UserIcon, Camera as CameraIcon, Car as CarIcon, CreditCard, ShieldCheck as ShieldCheckIcon, ArrowRight, Lock as LockIcon } from 'lucide-react';
import { Order, UserProfile } from '../types';
import { formatPrice } from '../lib/utils';
import { MockMap } from './MockMap';
import { cn } from '../lib/utils';

interface DriverAppProps {
  orders: Order[];
  user: UserProfile;
  onAcceptOrder: (orderId: string) => void;
  onCompleteOrder: (orderId: string) => void;
  onRejectOrder: (orderId: string) => void;
  onRecharge: () => void;
  isSubscribed: boolean;
  supportNumber: string;
  activeOrder?: Order;
  onToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export function DriverApp({ orders, user, onAcceptOrder, onCompleteOrder, onRejectOrder, onRecharge, isSubscribed, supportNumber, activeOrder, onToast }: DriverAppProps) {
  const [isOnline, setIsOnline] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showPayment, setShowPayment] = useState(false);
  const [isPaying, setIsPaying] = useState(false);

  const pendingOrders = orders.filter(o => {
    if (o.status !== 'pending') return false;
    
    // Filter by category
    const cat = user.driverCategory;
    if (o.serviceType === 'people') return cat === 'ligeiro';
    if (o.serviceType === 'merchandise') {
      const isLigeiro = cat === 'ligeiro';
      const isPesado = cat === 'pesado';
      if (isLigeiro && (user.carLuxury || 0) < 65) return false; // Ligeiro must be 65%+ luxury for merchandise
      return isLigeiro || isPesado;
    }
    if (o.serviceType === 'materials') return cat === 'pesado' || cat === 'pesado_profissional';
    
    return true;
  });

  const completedOrdersToday = orders.filter(o => {
    const isCompleted = o.status === 'completed';
    const isToday = new Date(o.createdAt).toDateString() === new Date().toDateString();
    return isCompleted && isToday && o.driverId === user.id;
  });

  const dailyEarnings = completedOrdersToday.reduce((acc, o) => acc + (o.price - (o.commission || 0)), 0);

  if (user.role === 'driver' && !user.isVerified) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-8 text-center bg-driver-dark">
        <div className="w-10 h-10 bg-primary-pink rounded-xl flex items-center justify-center text-white shadow-lg mb-6 transform rotate-3">
          <span className="text-xl font-extrabold font-display">A</span>
        </div>
        <div className="w-24 h-24 bg-driver-card rounded-full flex items-center justify-center mb-6 border border-white/5 shadow-2xl">
          <ShieldCheckIcon className="w-10 h-10 text-primary-yellow animate-pulse" />
        </div>
        <h2 className="text-2xl font-black mb-2 text-white font-display uppercase tracking-tight">Aguardando Verificação</h2>
        <p className="text-sm text-stone-400 mb-8 max-w-[280px] leading-relaxed italic">
          O seu perfil e documentos estão sendo analisados pelo administrador. Receberá uma notificação assim que for aprovado para trabalhar.
        </p>
        <div className="bg-driver-card p-6 rounded-[32px] border border-white/5 w-full max-w-xs shadow-2xl">
          <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-4 text-center">Status do Processo</p>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Identidade (BI)</span>
              <span className="text-[9px] bg-emerald-500 text-white px-3 py-1 rounded-full font-black uppercase">Ok</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Transporte</span>
              <span className="text-[9px] bg-emerald-500 text-white px-3 py-1 rounded-full font-black uppercase">Ok</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-stone-400 font-bold uppercase tracking-widest">Aprovação Admin</span>
              <span className="text-[9px] bg-primary-yellow text-primary-pink px-3 py-1 rounded-full font-black uppercase">Pendente</span>
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => window.location.reload()}
          className="mt-8 text-stone-500 text-xs font-black uppercase tracking-widest hover:text-white transition-colors"
        >
          Actualizar Status
        </button>
      </div>
    );
  }

  const handleProcessPayment = () => {
    setIsPaying(true);
    setTimeout(() => {
      onRecharge();
      setIsPaying(false);
      setShowPayment(false);
      onToast("PAGAMENTO RECEBIDO: Recarga activada com sucesso!");
    }, 3000);
  };

  if (showPayment) {
    return (
      <div className="flex flex-col h-full bg-white p-8">
        <div className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full text-center">
          <div className="w-20 h-20 bg-primary-pink rounded-3xl flex items-center justify-center text-white shadow-2xl mx-auto mb-6 transform rotate-3">
            <span className="text-4xl font-extrabold font-display">A</span>
          </div>
          <h2 className="text-2xl font-black text-stone-900 font-display mb-2">Recarga Mensal</h2>
          <p className="text-stone-500 text-sm mb-8">
            Para continuar a receber pedidos e utilizar a plataforma Amafrican, deve efectuar o pagamento da taxa mensal de serviço.
          </p>

          <div className="bg-stone-50 p-6 rounded-[32px] border-2 border-stone-100 mb-8">
            <p className="text-[10px] text-stone-400 font-black uppercase tracking-widest mb-1">Valor a pagar</p>
            <p className="text-4xl font-black text-primary-pink">{formatPrice(300)}</p>
            <p className="text-[10px] text-stone-400 font-bold uppercase mt-2 tracking-tighter italic">Válido por 30 dias</p>
          </div>

          <div className="space-y-4">
             <div className="flex flex-col items-center gap-2 p-4 bg-emerald-50 rounded-2xl border border-emerald-100 text-emerald-700 text-xs font-bold leading-tight">
               <ShieldCheckIcon size={20} />
               O valor será enviado directamente para o sistema Amafrican para activação imediata da sua conta.
             </div>
             
             <button 
               onClick={handleProcessPayment}
               disabled={isPaying}
               className="w-full bg-primary-yellow text-primary-pink py-4 rounded-2xl font-black shadow-xl shadow-yellow-500/20 disabled:opacity-50 flex items-center justify-center gap-2 uppercase tracking-widest text-sm"
             >
               {isPaying ? "Processando Pagamento..." : "CONFIRMAR E ENVIAR"}
               {!isPaying && <ArrowRight size={18} />}
             </button>

             <button 
               onClick={() => setShowPayment(false)}
               className="text-stone-400 text-xs font-bold uppercase tracking-widest py-2"
             >
               Cancelar
             </button>
          </div>
        </div>
      </div>
    );
  }

  if (!isOnline || !isSubscribed) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-8 text-center bg-driver-dark">
        <div className="w-24 h-24 bg-driver-card rounded-full flex items-center justify-center mb-6 border border-white/5 shadow-2xl">
          {(!isSubscribed && isOnline) ? <DollarSign className="w-10 h-10 text-primary-yellow" /> : <Power className="w-10 h-10 text-stone-600" />}
        </div>
        <h2 className="text-2xl font-black mb-2 text-white font-display">
          {!isSubscribed && isOnline ? 'Recarga Necessária' : 'Está Offline'}
        </h2>
        <p className="text-sm text-stone-400 mb-8 max-w-[200px]">
          {!isSubscribed && isOnline 
            ? `Deve efectuar o pagamento de ${formatPrice(300)} para activar os serviços por 30 dias.`
            : 'Fique online para começar a receber pedidos de transporte em sua zona.'}
        </p>
        {!isSubscribed && isOnline ? (
          <button 
            onClick={() => setShowPayment(true)}
            className="bg-primary-yellow text-primary-pink px-12 py-4 rounded-2xl font-black shadow-lg shadow-yellow-500/20 active:scale-95 transition-all uppercase tracking-widest text-sm"
          >
            PAGAR RECARGA (300 MT)
          </button>
        ) : (
          <button 
            onClick={() => setIsOnline(true)}
            className="bg-emerald-500 text-white px-12 py-4 rounded-2xl font-black shadow-lg shadow-emerald-500/20 active:scale-95 transition-all uppercase tracking-widest text-sm"
          >
            FICAR ONLINE
          </button>
        )}
      </div>
    );
  }

  if (activeOrder) {
    return (
      <div className="flex flex-col h-full bg-white">
        <div className="h-1/2 relative">
          <MockMap pickup={activeOrder.pickup} destination={activeOrder.destination} />
          <div className="absolute top-4 left-4 bg-primary-green text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg">
            EM NAVEGAÇÃO
          </div>
        </div>
        <div className="flex-1 p-6 bg-white rounded-t-3xl -mt-6 z-10 shadow-up flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold">Cliente: {activeOrder.customerName || 'Domingos P.'}</h3>
              <p className="text-sm text-primary-green font-bold">
                Recebe: {formatPrice(activeOrder.price - (activeOrder.commission || 0))}
              </p>
              <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest leading-none mt-1">
                Taxa Amafrican: {formatPrice(activeOrder.commission || 0)}
              </p>
            </div>
            <div className="flex gap-2">
              <a href={`tel:${activeOrder.customerPhone}`} className="p-3 bg-green-100 text-green-700 rounded-full">
                <Phone className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div className="flex-1 space-y-4">
             <div className="p-4 bg-stone-50 rounded-xl border border-stone-100">
               <div className="flex gap-3 mb-4">
                 <div className="flex flex-col items-center">
                   <div className="w-2 h-2 rounded-full bg-green-600" />
                   <div className="w-0.5 h-6 bg-stone-200" />
                   <div className="w-2 h-2 rounded-full bg-red-600" />
                 </div>
                 <div className="flex flex-col gap-4">
                   <div className="text-sm font-medium leading-none">{activeOrder.pickup.address}</div>
                   <div className="text-sm font-medium leading-none mt-1">{activeOrder.destination.address}</div>
                 </div>
               </div>
             </div>
             {activeOrder.cargoPhoto && (
               <div className="mt-2">
                 <p className="text-xs font-bold text-stone-500 uppercase mb-2">Foto da Carga</p>
                 <div className="w-full h-24 bg-stone-100 rounded-xl flex items-center justify-center border border-stone-200 overflow-hidden">
                   <Truck className="w-8 h-8 text-stone-300" />
                 </div>
               </div>
             )}
          </div>

          <button 
            onClick={() => onCompleteOrder(activeOrder.id)}
            className="w-full bg-primary-green text-white py-4 rounded-xl font-bold shadow-lg flex items-center justify-center gap-2 mt-4"
          >
            <CheckCircle size={20} />
            CONCLUIR SERVIÇO
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-driver-dark">
      <div className="p-6 pt-10 bg-driver-dark flex items-center justify-between border-b border-white/5">
         <button 
           onClick={() => setShowProfile(true)}
           className="flex items-center gap-4 text-left"
         >
           <div className="w-12 h-12 bg-white rounded-2xl border-2 border-primary-pink overflow-hidden flex items-center justify-center">
             {user.profilePhoto ? (
               <img src={user.profilePhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
             ) : (
               <UserIcon size={24} className="text-primary-pink" />
             )}
           </div>
           <div>
            <h2 className="text-sm font-black text-white font-display uppercase tracking-tight">{user.name}</h2>
            <p className="text-[10px] text-stone-500 font-bold uppercase tracking-widest">
              {user.carBrand || 'Sem Carro'} • {user.carLuxury || 0}% Luxo
            </p>
            <p className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 uppercase tracking-tighter mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Online
            </p>
           </div>
         </button>
         <div className="flex gap-2">
            <button 
              onClick={() => setIsOnline(false)}
              className="p-3 bg-driver-card rounded-2xl text-stone-500 hover:text-red-500 transition-colors border border-white/5"
            >
              <Power size={20} />
            </button>
         </div>
      </div>

      <AnimatePresence>
        {showProfile && (
          <motion.div 
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed inset-0 z-50 bg-driver-dark p-6 flex flex-col"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-xl font-black text-white font-display">Meu Perfil</h2>
              <button 
                onClick={() => setShowProfile(false)}
                className="p-3 bg-driver-card rounded-full text-white border border-white/5"
              >
                <X size={20} />
              </button>
            </div>

            <div className="space-y-6 overflow-y-auto pr-2 scrollbar-hide pb-20">
              <div className="flex flex-col items-center mb-4">
                <div className="w-10 h-10 bg-primary-pink rounded-xl flex items-center justify-center text-white shadow-lg mb-2 transform rotate-3">
                  <span className="text-xl font-extrabold font-display">A</span>
                </div>
                <h1 className="text-sm font-black text-white font-display">Amafrican</h1>
                <p className="text-[8px] text-primary-red font-bold uppercase tracking-[0.2em]">Conectando Moçambique</p>
              </div>

              <div className="bg-driver-card p-6 rounded-[32px] border border-white/5 flex flex-col items-center text-center">
                <div className="w-24 h-24 rounded-full border-4 border-primary-pink overflow-hidden mb-4 shadow-2xl">
                  <img src={user.profilePhoto || "https://images.unsplash.com/photo-1633332755192-727a05c4013d?w=400"} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <h3 className="text-lg font-black text-white">{user.name}</h3>
                <p className="text-xs text-stone-500 font-bold uppercase tracking-widest">{user.phone} • {user.birthDate}</p>
                <div className="flex gap-1 mt-2">
                  {[1,2,3,4,5].map(i => <span key={i} className="text-primary-yellow text-sm">★</span>)}
                </div>
              </div>

              <div className="bg-driver-card p-6 rounded-[32px] border border-white/5 space-y-5">
                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-primary-pink/10 rounded-xl flex items-center justify-center text-primary-pink">
                     <ShieldCheckIcon size={20} />
                   </div>
                   <div className="flex-1">
                     <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Identificação (BI)</p>
                     <p className="text-sm font-bold text-white uppercase">{user.biNumber || 'N/A'}</p>
                   </div>
                 </div>

                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-primary-pink/10 rounded-xl flex items-center justify-center text-primary-pink">
                     <CheckCircle size={20} />
                   </div>
                   <div className="flex-1">
                     <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Carta de Condução</p>
                     <p className="text-sm font-bold text-white uppercase uppercase">{user.driverCategory?.replace('_', ' ') || 'N/A'}</p>
                   </div>
                 </div>

                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-primary-pink/10 rounded-xl flex items-center justify-center text-primary-pink">
                     <CarIcon size={20} />
                   </div>
                   <div className="flex-1">
                     <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Transporte</p>
                     <p className="text-sm font-bold text-white uppercase">{user.vehicleSubCategory} • {user.vehicleCategory}</p>
                   </div>
                 </div>

                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-primary-pink/10 rounded-xl flex items-center justify-center text-primary-pink">
                     <LockIcon size={20} />
                   </div>
                   <div className="flex-1">
                     <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Matrícula</p>
                     <p className="text-sm font-bold text-white uppercase">{user.vehiclePlate || 'N/A'}</p>
                   </div>
                 </div>

                 <div className="space-y-4 pt-2">
                    <div>
                      <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-3">Fotos do Interior (2)</p>
                      <div className="grid grid-cols-2 gap-3">
                        {(user.vehiclePhotos?.inside || [null, null]).map((url, i) => (
                          <div key={`in-${i}`} className="aspect-square rounded-2xl overflow-hidden border border-white/10 bg-stone-800">
                             {url ? <img src={url} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <div className="w-full h-full flex items-center justify-center"><CameraIcon className="text-stone-600" size={16} /></div>}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-3">Fotos do Exterior (2)</p>
                      <div className="grid grid-cols-2 gap-3">
                        {(user.vehiclePhotos?.outside || [null, null]).map((url, i) => (
                          <div key={`out-${i}`} className="aspect-square rounded-2xl overflow-hidden border border-white/10 bg-stone-800">
                             {url ? <img src={url} className="w-full h-full object-cover" referrerPolicy="no-referrer" /> : <div className="w-full h-full flex items-center justify-center"><CameraIcon className="text-stone-600" size={16} /></div>}
                          </div>
                        ))}
                      </div>
                    </div>
                 </div>
              </div>

              <div className="bg-driver-card p-6 rounded-[32px] border border-white/5 flex items-center gap-4">
                <div className="w-12 h-12 bg-primary-pink/10 rounded-2xl flex items-center justify-center text-primary-pink">
                  <Phone size={24} />
                </div>
                <div className="flex-1">
                  <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Linha de Apoio</p>
                  <a href={`tel:${supportNumber}`} className="text-sm font-black text-white">{supportNumber}</a>
                </div>
              </div>

              <div className={cn(
                "p-6 rounded-[32px] border flex flex-col gap-4",
                isSubscribed ? "bg-emerald-500/5 border-emerald-500/10" : "bg-primary-red/5 border-primary-red/10"
              )}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center text-white",
                      isSubscribed ? "bg-emerald-500" : "bg-primary-red"
                    )}>
                      <CreditCard size={20} />
                    </div>
                    <div>
                      <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Recarga Mensal</p>
                      <p className={cn(
                        "text-sm font-bold uppercase",
                        isSubscribed ? "text-emerald-400" : "text-primary-red"
                      )}>
                        {isSubscribed ? 'Ativa / Pago' : 'Expirada / Pendente'}
                      </p>
                    </div>
                  </div>
                  {!isSubscribed && (
                    <button 
                      onClick={onRecharge}
                      className="bg-primary-yellow text-primary-pink px-4 py-2 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-yellow-500/20"
                    >
                      PAGAR
                    </button>
                  )}
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-2 pt-4 border-t border-white/5">
                   <div>
                     <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-1">Valor</p>
                     <p className="text-sm font-bold text-white">300.00 MT</p>
                   </div>
                   <div>
                     <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-1">Validade</p>
                     <p className="text-sm font-bold text-white">{isSubscribed ? '30 Dias' : 'Expirado'}</p>
                   </div>
                </div>
              </div>

              <div className="bg-driver-card p-6 rounded-[32px] border border-white/5 flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-500">
                  <CheckCircle size={20} />
                </div>
                <div>
                  <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest leading-none mb-1">Documentos</p>
                  <p className="text-sm font-bold text-white uppercase italic">Verificados</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex-1 p-6 space-y-6 overflow-y-auto">
        <div className="grid grid-cols-2 gap-4">
           <div className="bg-driver-card p-5 rounded-3xl border border-white/5 shadow-xl">
             <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-1">Ganhos Hoje</p>
             <p className="text-2xl font-black text-white">{formatPrice(dailyEarnings)}</p>
           </div>
           <div className="bg-driver-card p-5 rounded-3xl border border-white/5 shadow-xl">
             <p className="text-[10px] text-stone-500 font-black uppercase tracking-widest mb-1">Viagens</p>
             <p className="text-2xl font-black text-white">{completedOrdersToday.length}</p>
           </div>
        </div>

        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-stone-400 uppercase tracking-widest">
            Pedidos Próximos
          </h3>
          <span className="bg-primary-yellow text-primary-green text-[10px] px-3 py-1 rounded-full font-black">
            {pendingOrders.length} DISPONÍVEIS
          </span>
        </div>

        <AnimatePresence>
          {pendingOrders.map(order => (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="bg-white rounded-[32px] p-6 shadow-2xl relative overflow-hidden"
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className="bg-primary-yellow text-primary-pink text-[9px] px-2 py-0.5 rounded-full font-black uppercase tracking-wider mb-2 inline-block">Pedido Urgente</span>
                  <h4 className="font-black text-stone-900 text-xl leading-tight uppercase">{order.serviceType}</h4>
                  <p className="text-[10px] text-stone-400 font-bold uppercase tracking-widest mt-1">Distância: 4.2 km</p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-black text-emerald-600 leading-none">{formatPrice(order.price)}</div>
                  <p className="text-[8px] text-stone-400 font-black uppercase mt-1 tracking-widest">Lucro Estimado</p>
                </div>
              </div>
              
              <div className="space-y-3 mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 bg-stone-100 rounded-md flex items-center justify-center text-[10px]">📍</div>
                  <p className="text-xs font-medium text-stone-600 line-clamp-1">{order.pickup.address}</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 bg-stone-100 rounded-md flex items-center justify-center text-[10px]">🏁</div>
                  <p className="text-xs font-medium text-stone-600 line-clamp-1">{order.destination.address}</p>
                </div>
                {order.customerPhone && (
                  <div className="flex items-center gap-3 pt-1">
                    <div className="w-5 h-5 bg-emerald-50 rounded-md flex items-center justify-center text-[10px]">📞</div>
                    <p className="text-xs font-black text-emerald-600">{order.customerPhone}</p>
                  </div>
                )}
              </div>

              {(order.serviceType === 'merchandise' || order.serviceType === 'materials') && (
                <div className="mb-6 p-4 bg-stone-50 rounded-2xl border border-stone-100 space-y-3">
                  <p className="text-[10px] text-stone-400 font-black uppercase tracking-widest">Detalhes da Carga</p>
                  <p className="text-sm font-bold text-stone-800 leading-tight">
                    {order.cargoDescription || "Sem descrição"}
                  </p>
                  {order.cargoPhoto && (
                    <div className="aspect-video w-full rounded-xl overflow-hidden border border-stone-200">
                      <img src={order.cargoPhoto} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => onRejectOrder(order.id)}
                  className="py-4 bg-stone-100 text-stone-900 rounded-2xl font-black text-xs uppercase"
                >
                  Pular
                </button>
                <button 
                  onClick={() => onAcceptOrder(order.id)}
                  className="py-4 bg-primary-green text-white rounded-2xl font-black text-xs uppercase shadow-lg shadow-emerald-900/20 active:scale-95 transition-all"
                >
                  Aceitar
                </button>
              </div>
            </motion.div>
          ))}
          {pendingOrders.length === 0 && (
             <div className="py-12 text-center">
               <div className="inline-block p-4 bg-stone-100 rounded-full mb-4">
                 <Search className="w-8 h-8 text-stone-300 animate-pulse" />
               </div>
               <p className="text-sm text-stone-400">Procurando pedidos disponíveis...</p>
             </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
